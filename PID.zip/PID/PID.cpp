#include "PID.h"

PID* PID_New(double kp, double ki, double kd, long sampling_time, double max_out, byte error_tolerance )
{
   PID* pid = (PID*)calloc( 1 ,sizeof(PID));

   if( NULL != pid ){
      pid->error_tolerance=error_tolerance;
      pid->sampling_time = sampling_time;
      pid->max_out=max_out;
      pid->kp=kp;
      pid->ki=ki;
      pid->kd=kd;
      pid->stable=false;
   }

   return pid;
}

void PID_Delete(PID** pid )
{
   if(NULL != *pid ) free(*pid);
   *pid = NULL;   
}

double PID_out( PID* pid, double input, double set_point )
{  
   long time = micros();
   
   if( time - pid->pas_t  > pid->sampling_time ){
      
      pid->error = set_point - input; 
   
      pid->sum_error = pid->pas_error == pid->error ? pid->sum_error+pid->error : 0;
      pid->dif_error = pid->pas_error - pid->error;  
   
      pid->out = (pid->kp)*(pid->error)+(pid->ki)*(pid->sum_error)+(pid->kd)*(pid->dif_error);

      pid->out = pid->out > pid->max_out ? pid->max_out :pid->out;
      pid->out = pid->out < (-1)*pid->max_out ? (-1)*pid->max_out : pid->out;

      if( pid->dif_error == 0 &&  pid->error >= (-1)*pid->error_tolerance && pid->error <= pid->error_tolerance ) pid->stable = true; 
      else pid->stable = false; 
   
      pid->pas_error = pid->error;   
      pid->pas_t = micros();
   }
   return pid->out;
}

bool PID_SetPoint( PID* pid )
{ 
  return pid->stable;
}
