/**
* @file     PID.h
* @Author   CyberGato0515
* @date     08/5/2024
* @brief    Graph implementation
*/

/*

  _____      _                _____       _         ___  _____ __ _____ 
 / ____|    | |              / ____|     | |       / _ \| ____/_ | ____|
| |    _   _| |__   ___ _ __| |  __  __ _| |_ ___ | | | | |__  | | |__  
| |   | | | | '_ \ / _ \ '__| | |_ |/ _` | __/ _ \| | | |___ \ | |___ \ 
| |___| |_| | |_) |  __/ |  | |__| | (_| | || (_) | |_| |___) || |___) |
 \_____\__, |_.__/ \___|_|   \_____|\__,_|\__\___/ \___/|____/ |_|____/ 
        __/ |                                                           
       |___/                                                            

*/

#ifndef PID_H
#define PID_H

#include "Arduino.h"
#include <stdlib.h>
#include <assert.h>

typedef struct PID
{
   double  kp;
   double  ki;
   double  kd;
   double  max_out;
   double  out;
  
   long    sampling_time;
   long    pas_t;
    
   ////error///
   double pas_error;
   double error;          // error
   double sum_error;      // ∫error dt 
   double dif_error;      // d(error)/dt
   byte   error_tolerance;

   bool stable;
   
}PID;

PID*    PID_New     (double kp, double ki, double kd, long sampling_time, double max_out, byte error_tolerance );
void    PID_Delete  (PID** pid );
double  PID_out( PID* pid, double input, double set_point );
bool    PID_SetPoint( PID* pid );


#endif
